package com.example.my.tomato;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.Random;

/**
 * Created by Adam on 5/25/2015.
 */
public class Drawing extends View {
    public Drawing(Context context) {
        super(context);
    }
    //lots of initialization;
    float Vely = 0;
    float Velx = 0;
    static float accelx, accely;
    int c = 50, q =0; //counter for points and wall touches
    double Gx = 0, Gy=0, Fx =0, Fy =0 ;//init gravity and Friction

    int line1y = 0,line2y = 0, line1x = 0, line2x = 0;//line coords
    int tomatox = 50, tomatoy = 50, tomator = 55;// tomato coords
    int drainx = 0, drainy = 0, drainr = 95; // drain coords
    int canvasbot, canvasright, height, width;// canvas info

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        width = canvas.getWidth();
        height = canvas.getHeight();
        //actually setting of the coords, based off of canvas so it will work on all phones (hopefully)
        line1x = width*2/3; line1y = height/3;
        line2y = height*2/3; line2x = width/3;
        drainx = width*4/5; drainy = height*4/5;

        tomator = height/25;
        drainr =  height/16;

        canvasbot = canvas.getHeight();
        canvasright = canvas.getWidth();
        //two lines
        Paint paint = new Paint(40);
        paint.setStrokeWidth(25);
        paint.setColor(Color.LTGRAY);
        canvas.drawRect(0,0, canvas.getWidth(),canvas.getHeight(), paint);
        paint.setColor(Color.BLACK);
        canvas.drawLine(0, line1y, line1x, line1y, paint);
        canvas.drawLine(line2x, line2y, 1200, line2y, paint);

        //random color for the drain
        paint.setStrokeWidth(10);
        Random r = new Random();
        int n = r.nextInt(100000);
        Paint pain= new Paint(40);//For random color of drain (was board)
            pain.setColor(randomColor());
        if(n < 1) {
            paint=pain;
        }
        canvas.drawCircle(drainx, drainy, drainr, pain);

        //tomato
        paint.setColor(Color.RED);
        canvas.drawCircle(tomatox, tomatoy, tomator, paint);
        //Wall Touches
        paint.setTextSize(height/28);//change to text
        canvas.drawText("Wall Touches: "+ c , width*1/3, height/15, paint);
        //points
        paint.setColor(Color.GREEN);
        canvas.drawText("Points: "+ q , width/40, height/15, paint);
    }
    public void physics() {
        float alpha = (float) .075, beta = (float) .075;

        Velx += accelx;
        Vely += accely;

        Fx = -alpha * Velx;
        Fy = -alpha * Vely;

        Gx = beta * accelx;
        Gy = beta * accely;

        tomatox += (int) Gx - (int) Fx;
        tomatoy += (int) Gy - (int) Fy;

        //checks to make sure does not go offscreen
        //topline
        if (tomatoy - tomator < 0) {
            Vely *= -.71;
            tomatoy = tomator;
            c--;
        }
        //botline
        if (tomatoy + tomator > height) {
            Vely *= -.71;
            tomatoy = height - tomator;
            c--;
        }
        //left
        if (tomatox - tomator < 0) {
            Velx *= -.71;
            tomatox = tomator;
            c--;
        }
        //right
        if (tomatox + tomator > width){
            Velx *= -.71;
            tomatox = width - tomator;
            c--;
        }

        //check if it hits line1
        if (tomatoy + tomator > line1y && tomatoy - tomator < line1y){
            if (tomatox > line1x) ;
            else if (tomatoy < line1y) {
                Vely *= -.71;
                tomatoy = line1y - tomator;
                c--;
            } else if (tomatoy > line1y) {
                Vely *= -.71;
                tomatoy = line1y + tomator;
                c--;
            }
        }
        //checks line2
        if (tomatoy + tomator > line2y && tomatoy-tomator < line2y) {
            if (tomatox < line2x);
            else if (tomatoy < line2y) {
                Vely *= -.71;
                tomatoy = line2y - tomator;
                c--;
            } else if (tomatoy > line2y) {
                Vely *= -.71;
                tomatoy = line2y + tomator;
                c--;
            }
        }

        int dif = height/16;

        //check if it went in drain
        if(tomatox > drainx && tomatoy > drainy){
            if(tomatox - drainx < dif && tomatoy - drainy < dif) {
                tomatox = 155;
                tomatoy = 155;
                q++;
            }
        }
        else if (tomatox > drainx && tomatoy < drainy){
                if(tomatox -drainx <dif && drainy - tomatoy<dif ) {
                    tomatox = 155;
                    tomatoy = 155;
                    q++;
                }
        }
        else if (tomatox < drainx && tomatoy > drainy){
                if(drainx - tomatox <dif && tomatoy - drainy <dif ) {
                    tomatox = 155;
                    tomatoy = 155;
                    q++;
                }
        }
        else if (tomatox < drainx && tomatoy < drainy) {
                 if (drainx - tomatox < dif && drainy - tomatoy < dif) {
                     tomatox = 155;
                     tomatoy = 155;
                     q++;
                 }
        }
    }

    int randomColor() {
        Random r = new Random();
           int red = r.nextInt(255);
           int green = r.nextInt(255);
           int blue = r.nextInt(255);
        return Color.rgb(red, green, blue);
    }
}