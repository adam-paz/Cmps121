package com.dealfaro.luca.serviceexample;

import java.util.Date;

/**
 * Created by luca on 7/5/2015.
 */
public class ServiceResult {
    ServiceResult() {}

    public boolean moved;
    public Date d = new Date(System.currentTimeMillis());
    long t2 = d.getTime();
    long t1;
    float ax;
    float ay;
}