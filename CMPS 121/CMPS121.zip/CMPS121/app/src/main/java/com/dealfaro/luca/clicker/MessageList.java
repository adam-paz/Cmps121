package com.dealfaro.luca.clicker;

/**
 * Created by luca on 14/4/2015.
 */
public class MessageList {
    public MessageList() {};

    message [] messages;

}
