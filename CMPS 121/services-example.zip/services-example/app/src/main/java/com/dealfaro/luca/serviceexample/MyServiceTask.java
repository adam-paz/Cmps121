package com.dealfaro.luca.serviceexample;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import java.util.Date;
import java.util.Random;

import de.greenrobot.event.EventBus;

/**
 * Created by luca on 7/5/2015.
 */
public class MyServiceTask implements Runnable {
    float accelx =0;
    float accely =0;
    ServiceResult result = new ServiceResult();

    public static final String LOG_TAG = "MyService";
    private boolean running;
    private Context context;



    public MyServiceTask(Context _context) {
        context = _context;

        ((SensorManager) context.getSystemService(Context.SENSOR_SERVICE)).registerListener(
                new SensorEventListener() {
                    @Override
                    public void onSensorChanged(SensorEvent event) {
                        // I hope I got the signs right.  If not, experiment with this.
                        result.ax = accelx = -event.values[0];
                        result.ay =accely = event.values[1];
                    }
                    @Override
                    public void onAccuracyChanged(Sensor sensor, int accuracy) {
                    } //ignore
                },
                ((SensorManager) context.getSystemService(Context.SENSOR_SERVICE)).getSensorList(Sensor.TYPE_ACCELEROMETER).get(0),
                SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    public void run() {
        running = true;
        Random rand = new Random();
        while (running) {
            Date d = new Date(System.currentTimeMillis());
            //checks movement
            if(result.ax < -1.5 || result.ax >1.5){
                result.moved = true;
            }
            if(result.ay > 1.5 || result.ay < -1.5){
                result.moved = true;
            }
            EventBus.getDefault().post(result);
        }
    }

    public void stopProcessing() {
        running = false;
    }

    public void setTaskState(boolean b) {
        // Do something with b.
    }


}
