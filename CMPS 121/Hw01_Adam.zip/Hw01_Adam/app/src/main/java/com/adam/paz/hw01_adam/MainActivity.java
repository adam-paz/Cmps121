package com.adam.paz.hw01_adam;

import android.content.DialogInterface;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static android.view.View.OnClickListener;


public class MainActivity extends ActionBarActivity {

    TextView number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number = (TextView) findViewById(R.id.number);
    }

    public void Delete (View v){
        String num=number.getText().toString();
        if(num.length()>=1) {
            num = num.substring(0, num.length() - 1);
            number.setText(num);
        }
    }

    public void callclear (View v){
        String num =number.getText().toString();
        num = "";
        number.setText(num);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //private OnClickListener onClickListener = new OnClickListener() {
    //   @Override
    public void Clicked(View v) {
        String text = number.getText().toString();
        if(text.length()>11) return;
        else {
            switch (v.getId()) {
                case R.id.zero:
                    //DO something
                    number.append("0");
                    break;
                case R.id.one:
                    //DO something
                    number.append("1");
                    break;
                case R.id.two:
                    //DO something
                    number.append("2");
                    break;
                case R.id.three:
                    number.append("3");
                    break;
                case R.id.four:
                    number.append("4");
                    break;
                case R.id.five:
                    number.append("5");
                    break;
                case R.id.six:
                    number.append("6");
                    break;
                case R.id.seven:
                    number.append("7");
                    break;
                case R.id.eight:
                    number.append("8");
                    break;
                case R.id.nine:
                    number.append("9");
                    break;
                case R.id.plus:
                    number.append("+");
                    break;
                case R.id.pound:
                    number.append("#");
            }
        }
    }

    // @Override
    public void onClick(View v) {

    }
};
