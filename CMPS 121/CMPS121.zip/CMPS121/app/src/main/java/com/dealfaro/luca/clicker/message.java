package com.dealfaro.luca.clicker;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Adam on 4/30/2015.
 */
public class message {
    public String msg;
    public String userid;
    public String dest;
    public String ts;
    public String msgid;
    public Boolean conversation;


public String getTime() {
        DateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
        targetFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        //Get current UTC time
        Date now = new Date();

        return ts;
        }
}